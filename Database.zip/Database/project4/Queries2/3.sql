SELECT DISTINCT o_orderdate
FROM orders
WHERE	o_orderdate>'1995-03-10' AND o_orderdate<'1995-03-20'

