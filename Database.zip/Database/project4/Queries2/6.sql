SELECT DISTINCT c_nationkey
FROM customer
WHERE c_custkey > 100 AND c_custkey < 150

