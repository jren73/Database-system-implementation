SELECT s_name, s_phone
FROM supplier
WHERE s_nationkey=10 AND s_acctbal<100.0

